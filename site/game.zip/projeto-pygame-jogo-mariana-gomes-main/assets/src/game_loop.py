
import pygame
from constantes import *
from Jogo import *


from Tela_Inicial import *
pygame.init()


proxima_tela = TELA_INICIAL
while proxima_tela != SAIR:
    if proxima_tela == TELA_INICIAL:
        jogo = Tela_Inicial()
        proxima_tela = jogo.mostrar()
    elif proxima_tela == TELA_JOGO:
        jogo = Jogo()
        proxima_tela = jogo.estado_jogo()
