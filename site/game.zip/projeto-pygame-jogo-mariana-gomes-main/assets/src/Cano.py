
import pygame
from Bloco import *
import random
pygame.init()
LARGURA = 1600
ALTURA = 900
SCREEN = pygame.display.set_mode((LARGURA, ALTURA))

class Canos: 
    def __init__(self):
        self.bloco = Bloco()
        self.x = LARGURA
        self.espaco = 200
        self.qnt_bloco = random.randint(2, 7)
        self.altura = self.qnt_bloco * self.bloco.altura_bloco
        self.largura_do_cano  = 50
        self.velocidade_do_cano = 3 
        self.velocidade_do_cano_vertical = 3
        

    def update(self):
        self.x -= self.velocidade_do_cano

    def off_screen(self):
        return self.x + self.largura_do_cano < 0

    def draw(self):
        # Desenha o cano superior
        # pygame.draw.rect(SCREEN, (0, 255,0), (self.x, 0, self.largura_do_cano, self.altura))
        self.altura += self.velocidade_do_cano_vertical
        if self.altura + 200 > ALTURA:
            self.velocidade_do_cano_vertical *= -1
        if self.altura < 0:
            self.velocidade_do_cano_vertical *= -1


        for i in range(1,20):
            SCREEN.blit(self.bloco.img_bloco,(self.x, self.altura - (i*50)))
        
        
        # Desenha o cano inferior
        # pygame.draw.rect(SCREEN, (0, 255 ,0), (self.x, self.altura + self.espaco, self.largura_do_cano , ALTURA - self.altura - self.espaco))

        for i in range(20):
            SCREEN.blit(self.bloco.img_bloco,(self.x, self.altura + self.espaco + (i*50)))