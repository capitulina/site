import pygame
from funcaotoshi import *
pygame.init()
LARGURA = 1600
ALTURA = 900
SCREEN = pygame.display.set_mode((LARGURA, ALTURA))

class Passaro (pygame.sprite.Sprite):   
    def __init__(self):
        pygame.sprite.Sprite.__init__(self)
        self.x = 700 #posicao x do passaro na tela
        self.y = ALTURA // 2 #posicao y do passaro na tela
        self.velocidade = 0 
        self.gravidade = 0.5
        self.lista_passaro = []
        self.tamanho_passaro = (70,70)
        self.asa = pygame.mixer.Sound('assets/sons/bird-wings-sound.ogg') 
        
         
        for i in range(1,12):
            nome = (f'assets/imagens/monster{i}.png')
            self.lista_passaro.append(pygame.transform.scale(pygame.image.load(nome),self.tamanho_passaro))
       
        self.rotacao = -2 

        self.animations = {
            STILL: self.lista_passaro[0:7]}
        # Define estado atual (que define qual animação deve ser mostrada)
        self.state = STILL
        # Define animação atual
        self.animation = self.animations[self.state]
        # Inicializa o primeiro quadro da animação
        self.frame = 0
        self.image = self.animation[self.frame]
        # Detalhes sobre o posicionamento.
        self.rect = self.image.get_rect()
        
        # Centraliza na tela.
        self.rect.centerx = self.x
        self.rect.centery = self.y  

        # Guarda o tick da primeira imagem
        self.last_update = pygame.time.get_ticks()

        # Controle de ticks de animação: troca de imagem a cada self.frame_ticks milissegundos.
        self.frame_ticks = 150 

    def jump(self):
        self.velocidade = -7
        self.asa.play()
         
 
    def update(self):
        self.velocidade  += self.gravidade
        self.y += self.velocidade

        # Verifica o tick atual.
        now = pygame.time.get_ticks()

        # Verifica quantos ticks se passaram desde a ultima mudança de frame.
        elapsed_ticks = now - self.last_update

        # Se já está na hora de mudar de imagem...
        if elapsed_ticks > self.frame_ticks:

            # Marca o tick da nova imagem.
            self.last_update = now

            # Avança um quadro.
            self.frame += 1

            # Atualiza animação atual
            self.animation = self.animations[self.state]
            # Reinicia a animação caso o índice da imagem atual seja inválido
            if self.frame >= len(self.animation):
                self.frame = 0
            
            # Armazena a posição do centro da imagem
            center = self.rect.center
            # Atualiza imagem atual
            self.image = self.animation[self.frame]
            # Atualiza os detalhes de posicionamento
            self.rect = self.image.get_rect()
            self.rect.center = center
    

    def draw(self):
        SCREEN.blit(pygame.transform.rotate(self.image, self.velocidade*self.rotacao) ,(self.x, self.y))