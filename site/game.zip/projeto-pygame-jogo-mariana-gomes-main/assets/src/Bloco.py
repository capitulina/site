import pygame
pygame.init()

class Bloco:
    def __init__(self):
        self.altura_bloco = 50
        img_bloco = pygame.image.load('assets/imagens/bloco.png')
        self.img_bloco = pygame.transform.scale(img_bloco, (50, 50))