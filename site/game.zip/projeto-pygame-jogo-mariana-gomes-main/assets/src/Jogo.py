import pygame
from Passaro import *
from Score import *
from Fundo import *
from Cano import *
from Tela_Inicial import *
import sys
pygame.init()

fonte = pygame.font.Font('assets/fontes/font.ttf', 30 )
BRANCO = (255, 255, 255)
PRETO = (0, 0, 0)
GREEN = (0, 255, 0) 

LARGURA = 1600
ALTURA = 900
SCREEN = pygame.display.set_mode((LARGURA, ALTURA))

pygame.mixer.music.load('assets/sons/Limbo OST ♬  Complete Original Soundtrack.mp3')
pygame.mixer.music.play(-1) 
pygame.mixer.music.set_volume(0.5)

class Jogo:
    def __init__(self):   
        self.passaro = Passaro()
        self.score = Score()
        self.fundo = Fundo()
        self.canos = []
        self.pipe_add_timer = 0
        self.pipe_speed_timer = 0
        self.clock = pygame.time.Clock()
        self.game = True
     
        
    
    def estado_jogo(self):
        all_sprites = pygame.sprite.Group()
        all_sprites.add(self.passaro)
        

        while self.game:
            self.fundo.pos_x_fundo_1 -= 2  # Move a primeira imagem de fundo para a esquerda
            self.fundo.pos_x_fundo_2 -= 2 
            if self.fundo.pos_x_fundo_1 <= -LARGURA:
                self.fundo.pos_x_fundo_1 = LARGURA  
            if self.fundo.pos_x_fundo_2 <= -LARGURA:
                self.fundo.pos_x_fundo_2 = LARGURA 

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit() 
                    sys.exit()
                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_SPACE or event.key == pygame.K_UP:
                        self.passaro.jump()

            # Atualizações do jogo 
            self.passaro.update()
            self.pipe_add_timer += 1
            self.pipe_speed_timer +=1

            if self.pipe_add_timer == 100:
                self.canos.append(Canos()) 
                self.pipe_add_timer = 0

            canos_ativos = [] 
            for cano in self.canos:
                cano.update() 
                if not cano.off_screen():
                    canos_ativos.append(cano)
        
            canos = canos_ativos

            # verifica colisoes
            for cano in canos:
                if self.passaro.x + self.passaro.tamanho_passaro[0]> cano.x and self.passaro.x < cano.x + cano.largura_do_cano :
                    if self.passaro.y < cano.altura or self.passaro.y + self.passaro.tamanho_passaro[1]> cano.altura + cano.espaco:
                        
                        while True:
                            pygame.mixer.music.stop() 
                            SCREEN.fill(PRETO)
                            texto_inicio = fonte.render(f"GAME OVER! / SCORE: {self.score.pontuacao}", True, BRANCO)
                            texto_inicio1 =fonte.render("press enter to restart" , True, BRANCO)
                            texto_rect = texto_inicio.get_rect(center=(LARGURA // 2, ALTURA // 2))
                            texto_rect1 = texto_inicio.get_rect(center=((LARGURA // 2 -20), 500))
                            SCREEN.blit(texto_inicio, texto_rect)
                            SCREEN.blit(texto_inicio1, texto_rect1)

                            for event in pygame.event.get():
                                    if event.type == pygame.QUIT:
                                        pygame.quit()
                                        sys.exit()
                                    elif event.type == pygame.KEYDOWN:
                                        if event.key == pygame.K_RETURN:
                                            
                                            print("enter pressed")
                                            pygame.mixer.music.play(-1) 
                                            return TELA_INICIAL
                                            
                            pygame.display.update()
                        
                    if cano.x == self.passaro.x:
                        self.score.pontuacao += 1  
                    
            # desenho na tela
            self.fundo.draw()
            
            for cano in canos:   
                cano.draw()
            self.passaro.draw()
            self.fundo.draw2()
            
            self.score.desenha_score()


            pygame.display.update() 
            self.clock.tick(160)  # limita a 160 fps

        pygame.quit()