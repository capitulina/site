import pygame
pygame.init()

LARGURA = 1600
ALTURA = 900
SCREEN = pygame.display.set_mode((LARGURA, ALTURA))

class Fundo:
    def __init__(self): 
        self.y = 0
        self.pos_x_fundo_1 = 0
        self.pos_x_fundo_2 = LARGURA
        
        fundo3 = pygame.image.load('assets/imagens/fundo3.png')
        self.fundo3 = pygame.transform.scale(fundo3, (LARGURA, ALTURA))
        
        img_fundo_1 = pygame.image.load('assets/imagens/imagem.png')
        self.img_fundo_1 = pygame.transform.scale(img_fundo_1, (LARGURA, ALTURA))
        img_fundo_2 = pygame.image.load('assets/imagens/imagem.png')
        self.img_fundo_2 = pygame.transform.scale(img_fundo_2, (LARGURA, ALTURA)) 
         
    def draw(self):
        SCREEN.blit(self.img_fundo_1, (self.pos_x_fundo_1, self.y))
        SCREEN.blit(self.img_fundo_2, (self.pos_x_fundo_2, self.y))

    def draw2(self):
        SCREEN.blit(self.fundo3,(0,0))