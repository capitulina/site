import pygame
pygame.init()
# Config da tela
LARGURA = 1600
ALTURA = 900
SCREEN = pygame.display.set_mode((LARGURA, ALTURA))

fonte = pygame.font.Font('assets/fontes/font.ttf', 30 )

class Score:
    def __init__(self):
        self.x = 30
        self.y = 30
        self.pontuacao = 0
    def desenha_score(self):
        texto_score = fonte.render(f"Score: {self.pontuacao}", True, (255, 255, 255))
        SCREEN.blit(texto_score, (self.x, self.y))  # Desenha o score no canto superior esquerdo