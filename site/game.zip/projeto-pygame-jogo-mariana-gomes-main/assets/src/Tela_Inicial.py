import pygame
# from Jogo import *
from constantes import *
import sys
pygame.init()

LARGURA = 1600
ALTURA = 900
SCREEN = pygame.display.set_mode((LARGURA, ALTURA))

BRANCO = (255, 255, 255)
PRETO = (0, 0, 0)
GREEN = (0, 255, 0) 

# Config da fonte7
fonte = pygame.font.Font('assets/fontes/font.ttf', 30 )

class Tela_Inicial:
    def __init__(self):
        self.mostra_tela_de_inicio = True
        # self.tela_jogo = Jogo()  

    def mostrar(self):
        while self.mostra_tela_de_inicio:
        
            SCREEN.fill(PRETO)
            texto_inicio = fonte.render('PRESS SPACE TO CONTINUE', True, BRANCO)
            texto_rect = texto_inicio.get_rect(center=(LARGURA // 2, ALTURA // 2))
            SCREEN.blit(texto_inicio, texto_rect)

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_SPACE or event.key == pygame.K_RETURN:
                        self.mostra_tela_de_inicio = False
                        return TELA_JOGO
                        
            pygame.display.update()
        return SAIR